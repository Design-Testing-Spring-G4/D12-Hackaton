
package controllers.user;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.GymRatingService;
import services.GymService;
import services.UserService;
import controllers.AbstractController;
import domain.Gym;
import domain.GymRating;
import domain.User;

@Controller
@RequestMapping("/gym/user")
public class GymUserController extends AbstractController {

	@Autowired
	private GymService			gymService;

	@Autowired
	private UserService			userService;

	@Autowired
	private GymRatingService	gymRatingService;


	// Display
	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display() {
		ModelAndView result;
		Gym gym;
		Collection<GymRating> grGym;
		double averageRating = 0.0;
		boolean hasGymUser = true;
		boolean alreadyRated = false;

		User principal;
		principal = this.userService.findByPrincipal();

		if (principal.getSubscription() == null) {
			hasGymUser = false;
			gym = null;
		} else {
			gym = principal.getSubscription().getGym();
			grGym = new ArrayList<GymRating>(gym.getGymRatings());
			final Collection<GymRating> grUser = new ArrayList<GymRating>(principal.getGymRatings());
			double allRatings = 0.0;
			for (final GymRating g : grGym) {
				allRatings += g.getRating();
				averageRating = allRatings / grGym.size();
				if (grUser.contains(g))
					alreadyRated = true;
			}
		}

		//Check if the user is subscribed to a gym and if he is subscribed to the gym displayed
		boolean isSubscribed = false;
		boolean hasSubscription = false;
		if (principal.getSubscription() != null) {
			hasSubscription = true;
			if (principal.getSubscription().getGym().equals(gym))
				isSubscribed = true;
		}

		result = new ModelAndView("gym/display");
		if (gym != null)
			result.addObject("gym", gym);

		result.addObject("hasGymUser", hasGymUser);
		result.addObject("principal", principal);
		result.addObject("averageRating", averageRating);
		result.addObject("alreadyRated", alreadyRated);
		result.addObject("isSubscribed", isSubscribed);
		result.addObject("hasSubscription", hasSubscription);

		return result;
	}

	@RequestMapping(value = "/rate", method = RequestMethod.GET)
	public ModelAndView rate(@RequestParam final int gymId, final int rating) {
		ModelAndView result;
		final Gym gym = this.gymService.findOne(gymId);
		final User principal = this.userService.findByPrincipal();

		final GymRating gr = this.gymRatingService.create();
		gr.setRating(rating);

		final Collection<GymRating> grUser = new ArrayList<GymRating>(principal.getGymRatings());
		final Collection<GymRating> grGym = new ArrayList<GymRating>(gym.getGymRatings());
		boolean alreadyRated = false;

		for (final GymRating g : grUser)
			if (grGym.contains(g))
				alreadyRated = true;

		Assert.isTrue(!alreadyRated);

		Assert.isTrue(principal.getSubscription().getGym().equals(gym));

		final GymRating saved = this.gymRatingService.save(gr);

		this.gymService.saveRating(gym, saved);

		this.userService.saveRating(principal, saved);

		result = new ModelAndView("redirect:/gym/display.do?gymId=" + gymId);

		return result;
	}

}
