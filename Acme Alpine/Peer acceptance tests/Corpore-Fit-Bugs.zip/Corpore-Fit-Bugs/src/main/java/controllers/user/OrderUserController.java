/*
 * ExerciseUserController.java
 * 
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package controllers.user;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.ProductOrderService;
import services.UserService;
import controllers.AbstractController;
import domain.OrderLine;
import domain.ProductOrder;

@Controller
@RequestMapping("/order/user")
public class OrderUserController extends AbstractController {


	@Autowired
	UserService userService;

	@Autowired
	ProductOrderService orderService;

	// Constructors -----------------------------------------------------------

	public OrderUserController() {
		super();
	}

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		List<OrderLine> lines = new ArrayList<OrderLine>();
		
		for (ProductOrder o : this.userService.findByPrincipal().getOrders()) {
			for (OrderLine ol : o.getOrderLines()) {
				lines.add(ol);
			}
		}
		result = new ModelAndView("order/list");
		result.addObject("orderLines", lines);
		result.addObject("requestURI", "order/user/list.do");
		return result;
	}


}
