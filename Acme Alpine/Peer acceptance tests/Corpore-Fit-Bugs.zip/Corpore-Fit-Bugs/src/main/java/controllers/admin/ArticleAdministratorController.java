
package controllers.admin;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ArticleRatingService;
import services.ArticleService;
import services.CommentService;
import controllers.AbstractController;
import domain.Article;
import domain.ArticleRating;
import domain.Comment;

@Controller
@RequestMapping("/article/admin")
public class ArticleAdministratorController extends AbstractController {

	@Autowired
	private CommentService			commentService;

	@Autowired
	private ArticleService			articleService;

	@Autowired
	private ArticleRatingService	articleRatingService;


	// Constructors -----------------------------------------------------------

	public ArticleAdministratorController() {
		super();
	}

	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView delete(@RequestParam final int articleId) {
		ModelAndView result;

		final Article article = this.articleService.findOne(articleId);

		try {

			final Collection<ArticleRating> articleRatings = new ArrayList<ArticleRating>(article.getArticleRatings());
			final Collection<Comment> comments = new ArrayList<Comment>(article.getComments());

			for (final ArticleRating ar : articleRatings)
				this.articleRatingService.delete(ar);

			for (final Comment c : comments) {
				article.getComments().remove(c);
				this.commentService.delete(c);
			}

			this.articleService.delete(article);

			result = new ModelAndView("redirect:/article/list.do");
		} catch (final Throwable oops) {
			result = this.createEditModelAndView("article.commit.error");
		}

		return result;
	}

	protected ModelAndView createEditModelAndView(final String message) {
		ModelAndView result;
		Collection<Article> articles;

		articles = this.articleService.findAllPublished();

		result = new ModelAndView("article/list");
		result.addObject("articles", articles);
		result.addObject("isListingCreated", false);
		result.addObject("requestURI", "article/list.do");

		result.addObject("message", message);

		return result;
	}

}
