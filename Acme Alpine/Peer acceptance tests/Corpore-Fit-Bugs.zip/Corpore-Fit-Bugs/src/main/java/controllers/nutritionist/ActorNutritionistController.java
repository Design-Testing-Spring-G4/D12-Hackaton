
package controllers.nutritionist;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.ActorService;
import services.DietService;
import services.NutritionistService;
import controllers.AbstractController;
import domain.Actor;
import domain.DaySchedule;
import domain.Diet;
import domain.Nutritionist;
import domain.User;

@Controller
@RequestMapping("/actor")
public class ActorNutritionistController extends AbstractController {

	@Autowired
	ActorService		actorService;

	@Autowired
	NutritionistService	nutritionistService;

	@Autowired
	DietService			dietService;


	//Edit Nutritionist
	@RequestMapping(value = "/nutritionist/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(Nutritionist nutritionist, final BindingResult binding) {
		ModelAndView result;
		nutritionist = this.nutritionistService.reconstruct(nutritionist, binding);
		if (binding.hasErrors())
			result = this.createEditModelAndView(nutritionist);
		else
			try {
				this.nutritionistService.save(nutritionist);
				result = new ModelAndView("redirect:/actor/display-principal.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(nutritionist, "actor.commit.error");
			}
		return result;
	}

	//Delete an nutritionist
	@RequestMapping(value = "/nutritionist/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(final int actorId) {
		ModelAndView result;
		final Nutritionist nutritionist = this.nutritionistService.findOne(actorId);
		Assert.isTrue(nutritionist.equals(this.actorService.findByPrincipal()));
		try {
			for (Diet d : nutritionist.getDiets()) {
				for (User u : this.dietService.getFollowers(d.getId())) {
					u.setDiet(null);
				}
			}
			for (User u : this.nutritionistService.getAssigners(nutritionist.getId())) {
				u.setNutritionist(null);
			}
			this.nutritionistService.delete(nutritionist);
			result = new ModelAndView("redirect:../../j_spring_security_logout");
		} catch (final Throwable oops) {
			result = this.createEditModelAndView(nutritionist, "actor.commit.error");
		}
		return result;
	}

	//Save a day schedule
	@RequestMapping(value = "/nutritionist/schedule/save", method = RequestMethod.POST, params = "save")
	public ModelAndView save(final String day, final String morningStart, final String morningEnd, final String afternoonStart, final String afternoonEnd) {
		ModelAndView result;
		final Nutritionist nutritionist = this.nutritionistService.findByPrincipal();
		Hibernate.initialize(nutritionist.getSchedule());
		final List<DaySchedule> schedule = nutritionist.getSchedule();
		Assert.notNull(schedule);
		try {
			this.nutritionistService.save(this.nutritionistService.addDaySchedule(day, morningStart, morningEnd, afternoonStart, afternoonEnd));
			result = new ModelAndView("redirect:/actor/nutritionist/schedule.do?nutritionistId=" + nutritionist.getId());
		} catch (final Throwable oops) {
			result = new ModelAndView("nutritionist/schedule");
			result.addObject("schedule", schedule);
			result.addObject("username", nutritionist.getUserAccount()
					.getUsername());
			result.addObject("message", "nutritionist.schedule.error");
			result.addObject("username", nutritionist.getUserAccount()
					.getUsername());
		}
		return result;
	}

	protected ModelAndView createEditModelAndView(final Actor actor) {
		ModelAndView result;
		result = this.createEditModelAndView(actor, null);
		return result;
	}

	protected ModelAndView createEditModelAndView(final Actor actor, final String message) {
		ModelAndView result;
		result = new ModelAndView("actor/edit");
		result.addObject(actor.getUserAccount().getAuthorities().toArray()[0].toString().toLowerCase(), actor);
		result.addObject("authority", actor.getUserAccount().getAuthorities().toArray()[0].toString().toLowerCase());
		result.addObject("message", message);
		result.addObject("actor", actor);
		return result;
	}
}
