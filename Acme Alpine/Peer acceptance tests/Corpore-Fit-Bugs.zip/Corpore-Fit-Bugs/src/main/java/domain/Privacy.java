
package domain;

public enum Privacy {
	OPEN, FRIENDS, CLOSED
}
