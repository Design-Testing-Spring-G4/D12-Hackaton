
package domain;

import java.util.Calendar;
import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.URL;

@Entity
@Access(AccessType.PROPERTY)
public class Article extends DomainEntity {

	private String				title;
	private String				body;
	private Collection<String>	images;
	private boolean				draft;
	private Calendar			publicationDate;
	private String				principalImage;


	@NotBlank
	public String getTitle() {
		return this.title;
	}

	public void setTitle(final String title) {
		this.title = title;
	}

	@NotBlank
	public String getBody() {
		return this.body;
	}

	public void setBody(final String body) {
		this.body = body;
	}

	@NotNull
	@ElementCollection
	public Collection<String> getImages() {
		return this.images;
	}

	public void setImages(final Collection<String> images) {
		this.images = images;
	}

	public boolean isDraft() {
		return this.draft;
	}

	public void setDraft(final boolean draft) {
		this.draft = draft;
	}

	public Calendar getPublicationDate() {
		return this.publicationDate;
	}

	public void setPublicationDate(final Calendar publicationDate) {
		this.publicationDate = publicationDate;
	}

	@NotBlank
	@URL
	public String getPrincipalImage() {
		return this.principalImage;
	}

	public void setPrincipalImage(final String principalImage) {
		this.principalImage = principalImage;
	}


	//Relationships

	private Editor						editor;
	private Collection<ArticleRating>	articleRatings;
	private Collection<Comment>			comments;


	@NotNull
	@Valid
	@ManyToOne(optional = false)
	public Editor getEditor() {
		return this.editor;
	}

	public void setEditor(final Editor editor) {
		this.editor = editor;
	}

	@NotNull
	@Valid
	@OneToMany(cascade = CascadeType.ALL)
	public Collection<ArticleRating> getArticleRatings() {
		return this.articleRatings;
	}

	public void setArticleRatings(final Collection<ArticleRating> articleRatings) {
		this.articleRatings = articleRatings;
	}

	@NotNull
	@Valid
	@OneToMany
	public Collection<Comment> getComments() {
		return this.comments;
	}

	public void setComments(final Collection<Comment> comments) {
		this.comments = comments;
	}
}
