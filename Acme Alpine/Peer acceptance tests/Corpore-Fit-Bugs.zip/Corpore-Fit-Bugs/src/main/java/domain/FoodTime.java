
package domain;

public enum FoodTime {
	BREAKFAST, MIDMORNING_SNACK, LUNCH, MIDAFTERNOON_SNACK, DINNER
}
