
package domain;

public enum SNetwork {
	TWITTER, INSTAGRAM, FACEBOOK, YOUTUBE
}
